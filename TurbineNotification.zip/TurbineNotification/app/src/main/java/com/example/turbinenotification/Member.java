package com.example.turbinenotification;

public class Member {

    private String name;

    public Member() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

